 ______________________________________________________________________
>                                                                      <
>                          PICos release 1.05                          <
>                                                                      <
>       PICOS - Real-time kernel for PIC24/PIC30/PIC33 families        <
>                                                                      <
>                                                                      <
> www.picos18.com                                    www.pragmatec.net <
>______________________________________________________________________<



PICos is a preemptive real-time kernel for 16bits PICs based on the OSEK 
automotive standart.
The application is running on Windows / MPLAB IDE.
The code is open source and is distributed under GLP license.

Please see the INSTALL.txt file to get instructions on how to install PICos18.
Please see the HISTORY.txt file to see the new features of PICos18.
Please see the PROCESSORS.txt file to see a list of tested processors.
Please see the LICENSE.txt file for the GPL license.


NOTE:
-----

This version is not yet fully compliant with OSEK standart and needs to be 
improved. Visit "http://www.picos18.com" to keep you inform of the PICos 
new improvements.

For any question visit www.picos18.com/forum.